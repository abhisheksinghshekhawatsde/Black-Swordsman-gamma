"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { apiService } from "@/lib/api/service";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem("rpa_user");
    if (storedUser) {
      try {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setUser(JSON.parse(storedUser));
      } catch (err) {
        console.error("Failed to parse cached user", err);
      }
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    setLoading(true);
    const res = await apiService.login(email, password);
    if (res.success) {
      localStorage.setItem("rpa_access_token", res.access_token);
      localStorage.setItem("rpa_user", JSON.stringify(res.user));
      setUser(res.user);
      setLoading(false);
      return { success: true };
    } else {
      setLoading(false);
      return { success: false, error: res.error };
    }
  };

  const logout = () => {
    localStorage.removeItem("rpa_access_token");
    localStorage.removeItem("rpa_user");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
