"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import {
  LayoutDashboard,
  BarChart3,
  LogOut,
  Menu,
  ChevronLeft,
  ChevronRight,
  User,
  Cpu,
  ShieldAlert,
  Layers,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { mockProcesses } from "@/data/mock";

export default function OperationsShell({ children }) {
  const { user, logout } = useAuth();
  const pathname = usePathname();
  const router = useRouter();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleLogout = () => {
    logout();
    router.replace("/login");
  };

  const navLinks = [
    { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { label: "Analytics", href: "/analytics", icon: BarChart3 },
  ];

  const processLinks = [
    { label: "SKI User Creation", code: "SKI_USER_CREATION", icon: Cpu },
    { label: "Loan Suraksha Policy", code: "LOAN_SURAKSHA_POLICY", icon: ShieldAlert },
    { label: "FinnOne User Creation", code: "FINNONE_USER_CREATION", icon: Cpu },
    { label: "FinnOne User Deactivation", code: "FINNONE_USER_DEACTIVATION", icon: Cpu },
    { label: "Branch Hierarchy", code: "BRANCH_HIERARCHY", icon: Layers },
    { label: "Azure User Creation", code: "AZURE_USER_CREATION", icon: Cpu },
  ];

  // Desktop/Mobile Navigation Content wrapper supporting collapsed styles
  const renderSidebarContent = (forceExpanded = false) => {
    const showCompact = isCollapsed && !forceExpanded;

    return (
      <div className="relative flex flex-col h-full bg-[var(--sidebar-bg)] border-r border-[var(--sidebar-border)] text-[var(--sidebar-text)] transition-all duration-150 select-none">
        {/* Sidebar Header Brand */}
        <div className={`flex items-center gap-3 px-6 py-5 border-b border-[var(--sidebar-border)] ${showCompact ? "justify-center px-4" : ""}`}>
          <div className="relative h-10 w-8 shrink-0">
            <Image
              src="/branding/logo-main.png"
              alt="SK Finance Logo"
              fill
              sizes="32px"
              className="object-contain"
              priority
            />
          </div>
          {!showCompact && (
            <div>
              <h1 className="text-xs font-bold text-slate-900 tracking-wide uppercase">SK Finance</h1>
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest leading-none mt-1">
                RPA Operations
              </p>
            </div>
          )}
        </div>

        {/* Navigation Groups */}
        <div className="flex-1 px-4 py-6 space-y-7 overflow-y-auto">
          {/* Workspace Group */}
          <div className="space-y-1">
            {!showCompact && (
              <p className="px-3 text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                Workspace
              </p>
            )}
            <nav className="space-y-0.5" aria-label="Main Navigation">
              {navLinks.map((link) => {
                const Icon = link.icon;
                const isActive = pathname === link.href;
                
                const linkElement = (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setIsMobileOpen(false)}
                    className={`flex items-center gap-3 py-2 text-xs font-semibold rounded-md transition-colors ${
                      showCompact ? "justify-center px-2" : "px-3"
                    } ${
                      isActive
                        ? "bg-[#1d4ed8] text-white"
                        : "hover:bg-[var(--sidebar-hover-bg)] hover:text-slate-900"
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    {!showCompact && <span>{link.label}</span>}
                  </Link>
                );

                if (showCompact) {
                  return (
                    <Tooltip key={link.href} delayDuration={100}>
                      <TooltipTrigger asChild>
                        {linkElement}
                      </TooltipTrigger>
                      <TooltipContent side="right" className="text-xs font-semibold border-slate-200 bg-white text-slate-800">
                        {link.label}
                      </TooltipContent>
                    </Tooltip>
                  );
                }

                return linkElement;
              })}
            </nav>
          </div>

          {/* Process Routines Group */}
          <div className="space-y-1">
            {!showCompact && (
              <p className="px-3 text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                Active Routines
              </p>
            )}
            <nav className="space-y-0.5" aria-label="Process Workflow Navigation">
              {processLinks.map((proc) => {
                const targetHref = `/process/${proc.code}`;
                const isActive = pathname === targetHref;
                const Icon = proc.icon;

                const linkElement = (
                  <Link
                    key={proc.code}
                    href={targetHref}
                    onClick={() => setIsMobileOpen(false)}
                    className={`flex items-center gap-3 py-2 text-xs font-medium rounded-md transition-colors truncate ${
                      showCompact ? "justify-center px-2" : "px-3"
                    } ${
                      isActive
                        ? "bg-blue-50 text-[#1d4ed8] font-semibold border-l-2 border-[#1d4ed8]"
                        : "hover:bg-[var(--sidebar-hover-bg)] hover:text-slate-900"
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    {!showCompact && (
                      <>
                        <span className="truncate flex-1">{proc.label}</span>
                        <ChevronRight className="h-3 w-3 shrink-0 opacity-45" />
                      </>
                    )}
                  </Link>
                );

                if (showCompact) {
                  return (
                    <Tooltip key={proc.code} delayDuration={100}>
                      <TooltipTrigger asChild>
                        {linkElement}
                      </TooltipTrigger>
                      <TooltipContent side="right" className="text-xs font-semibold border-slate-200 bg-white text-slate-800">
                        {proc.label}
                      </TooltipContent>
                    </Tooltip>
                  );
                }

                return linkElement;
              })}
            </nav>
          </div>
        </div>

        {/* Sidebar Footer User Detail Section */}
        <div className={`p-4 border-t border-[var(--sidebar-border)] bg-slate-50/50 flex flex-col gap-3 ${showCompact ? "items-center px-2" : ""}`}>
          {showCompact ? (
            <Tooltip delayDuration={100}>
              <TooltipTrigger asChild>
                <div className="relative flex items-center justify-center h-8 w-8 rounded-full bg-slate-100 border border-slate-200 text-slate-600 shrink-0 cursor-pointer overflow-hidden">
                  <User className="h-5 w-5 mt-1" />
                </div>
              </TooltipTrigger>
              <TooltipContent side="right" className="text-xs font-semibold border-slate-200 bg-white text-slate-800">
                Deepanshu Soni (Admin)
              </TooltipContent>
            </Tooltip>
          ) : (
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-3 min-w-0">
                <div className="relative flex items-center justify-center h-8 w-8 rounded-full bg-slate-100 border border-slate-200 text-slate-600 shrink-0 overflow-hidden">
                  <User className="h-5 w-5 mt-1" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-slate-800 truncate leading-tight">
                    Deepanshu Soni
                  </p>
                  <p className="text-[9px] font-bold text-[#1d4ed8] tracking-widest uppercase">
                    Admin
                  </p>
                </div>
              </div>

              {/* Logout Action Control */}
              <Tooltip delayDuration={100}>
                <TooltipTrigger
                  onClick={handleLogout}
                  aria-label="Log out"
                  className="flex items-center justify-center h-8 w-8 rounded-md text-slate-500 hover:text-red-600 hover:bg-red-50 transition-all shrink-0 cursor-pointer"
                >
                  <LogOut className="h-4 w-4" />
                </TooltipTrigger>
                <TooltipContent side="top" className="text-[10px] font-bold uppercase tracking-wider border-slate-200 bg-white text-slate-800">
                  Log out
                </TooltipContent>
              </Tooltip>
            </div>
          )}

          {showCompact && (
            <Tooltip delayDuration={100}>
              <TooltipTrigger
                onClick={handleLogout}
                aria-label="Log out"
                className="flex items-center justify-center h-8 w-8 rounded-md text-slate-500 hover:text-red-600 hover:bg-red-50 transition-all shrink-0 cursor-pointer"
              >
                <LogOut className="h-4 w-4" />
              </TooltipTrigger>
              <TooltipContent side="right" className="text-xs font-semibold border-slate-200 bg-white text-slate-800">
                Log out
              </TooltipContent>
            </Tooltip>
          )}
        </div>

        {/* Sidebar Toggle Button positioned directly at the bottom-right border fold */}
        {!forceExpanded && (
          <button
            onClick={() => setIsCollapsed((prev) => !prev)}
            type="button"
            className="hidden lg:flex absolute top-1/2 -right-3 -translate-y-1/2 items-center justify-center h-6 w-6 rounded-full border border-[#1d4ed8] bg-[#1d4ed8] text-white hover:bg-[#1e40af] transition-all shadow-md cursor-pointer z-50"
            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {isCollapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
          </button>
        )}
      </div>
    );
  };

  return (
    <div className="flex h-screen w-screen bg-[var(--canvas)] overflow-hidden font-sans">
      {/* Desktop Sidebar (Toggles width dynamically between 240px and 72px) */}
      <aside className={`hidden lg:block shrink-0 h-full transition-all duration-150 ${isCollapsed ? "w-[72px]" : "w-[240px]"}`}>
        {renderSidebarContent(false)}
      </aside>

      {/* Main Application Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Top Navigation Header */}
        <header className="h-[56px] bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            {/* Mobile Sheet Trigger */}
            <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
              <SheetTrigger className="lg:hidden p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors h-8 w-8 flex items-center justify-center cursor-pointer">
                <Menu className="h-5 w-5" />
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-[240px] bg-white border-r border-slate-200">
                {renderSidebarContent(true)}
              </SheetContent>
            </Sheet>

            {/* Breadcrumb Indicator */}
            <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
              <span>Operations Console</span>
              <span>/</span>
              <span className="text-slate-800 font-semibold">
                {pathname === "/dashboard"
                  ? "Dashboard"
                  : pathname === "/analytics"
                  ? "Analytics"
                  : (() => {
                      const code = pathname.startsWith("/process/")
                        ? pathname.replace("/process/", "").toUpperCase().replace(/-/g, "_")
                        : null;
                      const proc = code
                        ? mockProcesses.find((p) => p.code === code)
                        : null;
                      return proc ? proc.name : "Process Workspace";
                    })()}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-bold tracking-wide uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Engine Online
            </span>
          </div>
        </header>

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto px-6 py-6 md:px-8 lg:px-10 xl:px-12">
          <div className="w-full space-y-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
