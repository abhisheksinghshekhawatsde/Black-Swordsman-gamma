"use client";

import React from "react";
import {
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Loader2,
  Minus,
} from "lucide-react";

// Status vocabulary: PROCESSING | COMPLETED | COMPLETED WITH ERRORS | FAILED
export default function BatchStatus({ status }) {
  switch (status) {
    case "COMPLETED":
      return (
        <span className="inline-flex items-center gap-1.5 text-emerald-700">
          <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
          <span className="text-[11px] font-bold uppercase tracking-wide">Completed</span>
        </span>
      );
    case "COMPLETED WITH ERRORS":
      return (
        <span className="inline-flex items-center gap-1.5 text-amber-600">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          <span className="text-[11px] font-bold uppercase tracking-wide">With Errors</span>
        </span>
      );
    case "FAILED":
      return (
        <span className="inline-flex items-center gap-1.5 text-rose-600">
          <XCircle className="h-3.5 w-3.5 shrink-0" />
          <span className="text-[11px] font-bold uppercase tracking-wide">Failed</span>
        </span>
      );
    case "PROCESSING":
      return (
        <span className="inline-flex items-center gap-1.5 text-[#1d4ed8]">
          <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin" />
          <span className="text-[11px] font-bold uppercase tracking-wide">Processing</span>
        </span>
      );
    default:
      return (
        <span className="inline-flex items-center gap-1.5 text-slate-400">
          <Minus className="h-3.5 w-3.5 shrink-0" />
          <span className="text-[11px] font-bold uppercase tracking-wide">Unknown</span>
        </span>
      );
  }
}
