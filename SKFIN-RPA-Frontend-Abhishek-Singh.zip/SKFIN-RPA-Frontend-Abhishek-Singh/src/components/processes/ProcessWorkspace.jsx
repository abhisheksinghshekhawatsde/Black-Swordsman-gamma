"use client";

import React, { useState, useMemo } from "react";
import Link from "next/link";
import {
  Search,
  X,
  ChevronLeft,
  ChevronRight,
  Upload,
  Download,
  FileSpreadsheet,
  AlertCircle,
  ArrowLeft,
} from "lucide-react";

import { mockProcesses, mockDashboardSummary, mockBatches } from "@/data/mock";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import BatchStatus from "@/components/processes/BatchStatus";

const PAGE_SIZE = 10;

// Normalize incoming URL param: convert hyphens to underscores, uppercase
function normalizeCode(raw) {
  return raw?.toUpperCase().replace(/-/g, "_") ?? "";
}

function formatDate(isoString) {
  if (!isoString) return "—";
  const d = new Date(isoString);
  return d.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

function getCategoryBadgeColor(category) {
  switch (category) {
    case "FinnOne": return "text-[#1d4ed8] bg-blue-50 border-blue-200";
    case "SKI":     return "text-emerald-700 bg-emerald-50 border-emerald-200";
    case "AZURE":   return "text-purple-700 bg-purple-50 border-purple-200";
    default:        return "text-slate-600 bg-slate-50 border-slate-200";
  }
}

export default function ProcessWorkspace({ rawCode }) {
  const processCode = normalizeCode(rawCode);

  // Lookup process definition
  const processDef = mockProcesses.find((p) => p.code === processCode) ?? null;

  // Lookup summary metrics from dashboard summary
  const summaryMetrics = mockDashboardSummary.processes.find(
    (p) => p.process_code === processCode
  ) ?? null;

  // All batches for this process (memoized for stable reference)
  const allBatches = useMemo(
    () => mockBatches[processCode] ?? [],
    [processCode]
  );

  // Search state
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  // Filtered batches
  const filteredBatches = useMemo(() => {
    if (!searchQuery.trim()) return allBatches;
    const q = searchQuery.trim().toLowerCase();
    return allBatches.filter(
      (b) =>
        b.file_name.toLowerCase().includes(q) ||
        b.status.toLowerCase().includes(q)
    );
  }, [allBatches, searchQuery]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filteredBatches.length / PAGE_SIZE));
  const paginatedBatches = filteredBatches.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );
  const rangeStart = filteredBatches.length === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1;
  const rangeEnd = Math.min(currentPage * PAGE_SIZE, filteredBatches.length);

  // Reset page on search change
  const handleSearch = (val) => {
    setSearchQuery(val);
    setCurrentPage(1);
  };

  // ── Invalid process ──────────────────────────────────────────────
  if (!processDef) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[420px] border border-slate-200 rounded-lg bg-white p-8 text-center space-y-4">
        <div className="flex items-center justify-center h-12 w-12 rounded-full bg-slate-100 text-slate-400">
          <AlertCircle className="h-6 w-6" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Process not found</h2>
          <p className="text-xs text-slate-500 mt-1 max-w-sm">
            The requested automation process <span className="font-mono text-slate-700">{processCode}</span> does not
            exist in the current RPA registry.
          </p>
        </div>
        <Link href="/dashboard">
          <Button size="sm" variant="outline" className="text-xs font-semibold border-slate-200 hover:bg-slate-50">
            <ArrowLeft className="h-3.5 w-3.5 mr-2" />
            Back to Process Registry
          </Button>
        </Link>
      </div>
    );
  }

  const uiConfig = processDef.ui_config;
  const canUpload = uiConfig?.page_config?.buttons?.upload_excel !== false
    && uiConfig?.actions?.length > 0
    && false; // Disabled — no real upload endpoint
  const canDownload = uiConfig?.page_config?.buttons?.download_data === true;

  // ── Main workspace ───────────────────────────────────────────────
  return (
    <div className="space-y-6">

      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider" aria-label="Breadcrumb">
        <Link href="/dashboard" className="hover:text-[#1d4ed8] transition-colors">
          Process Registry
        </Link>
        <span>/</span>
        <span className={`px-1.5 py-0.5 rounded text-[10px] border ${getCategoryBadgeColor(processDef.category)}`}>
          {processDef.category}
        </span>
        <span>/</span>
        <span className="text-slate-700">{processDef.name}</span>
      </nav>

      {/* Process Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between border-b border-slate-200 pb-5">
        <div className="space-y-1.5">
          <h1 className="text-xl font-extrabold text-slate-900 tracking-tight leading-tight">
            {processDef.name}
          </h1>
          <p className="text-[10px] font-mono font-bold text-slate-400 tracking-widest uppercase">
            {processDef.code}
          </p>
          {processDef.description && (
            <p className="text-xs text-slate-500 leading-relaxed max-w-2xl mt-2">
              {processDef.description}
            </p>
          )}
          <div className="flex items-center gap-2 pt-1">
            <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${getCategoryBadgeColor(processDef.category)}`}>
              {processDef.category}
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Active
            </span>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              v{processDef.version}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 self-start shrink-0">
          {/* Upload — only shown if process has upload action */}
          {uiConfig?.actions?.some((a) => a.type?.includes("UPLOAD") || a.type?.includes("CREATE")) && (
            <Button
              variant="outline"
              size="sm"
              disabled
              title="Upload requires backend connection"
              className="h-8 text-xs font-semibold border-slate-200 bg-white text-slate-400 cursor-not-allowed"
            >
              <Upload className="h-3.5 w-3.5 mr-1.5" />
              Upload
            </Button>
          )}

          {/* Download */}
          {canDownload && (
            <Button
              variant="outline"
              size="sm"
              disabled
              title="Download requires backend connection"
              className="h-8 text-xs font-semibold border-slate-200 bg-white text-slate-400 cursor-not-allowed"
            >
              <Download className="h-3.5 w-3.5 mr-1.5" />
              Download Data
            </Button>
          )}
        </div>
      </div>

      {/* Metrics Strip */}
      {summaryMetrics && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-white border border-slate-200 rounded-lg px-4 py-3">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Total Batches</p>
            <p className="text-lg font-black text-slate-900 tracking-tight mt-0.5">{summaryMetrics.total_batches}</p>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg px-4 py-3">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Total Records</p>
            <p className="text-lg font-black text-slate-900 tracking-tight mt-0.5">{summaryMetrics.total_records}</p>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg px-4 py-3">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Success Rate</p>
            <p className={`text-lg font-black tracking-tight mt-0.5 ${summaryMetrics.success_rate >= 50 ? "text-emerald-700" : summaryMetrics.success_rate >= 15 ? "text-amber-700" : "text-rose-700"}`}>
              {summaryMetrics.success_rate.toFixed(1)}%
            </p>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg px-4 py-3">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Last Execution</p>
            <p className="text-xs font-bold text-slate-700 tracking-tight mt-0.5">
              {summaryMetrics.last_batch_at ? formatDate(summaryMetrics.last_batch_at) : "—"}
            </p>
          </div>
        </div>
      )}

      {/* Batch Execution Table */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        {/* Table Header Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 px-5 py-4 border-b border-slate-100">
          <div>
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Execution History</h2>
            <p className="text-[10px] text-slate-400 font-medium mt-0.5">
              {filteredBatches.length === allBatches.length
                ? `${allBatches.length} batch execution${allBatches.length !== 1 ? "s" : ""} recorded`
                : `${filteredBatches.length} of ${allBatches.length} matching`}
            </p>
          </div>

          {/* Search */}
          {allBatches.length > 0 && (
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                placeholder="Search file name or status…"
                aria-label="Search batches"
                className="w-full pl-8 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1d4ed8] focus:border-[#1d4ed8] placeholder:text-slate-400 text-slate-900"
              />
              {searchQuery && (
                <button
                  onClick={() => handleSearch("")}
                  aria-label="Clear search"
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Empty state — no batches at all */}
        {allBatches.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center space-y-3 px-6">
            <div className="flex items-center justify-center h-10 w-10 rounded-full bg-slate-100 text-slate-400">
              <FileSpreadsheet className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-700 uppercase tracking-wide">No executions yet</p>
              <p className="text-[11px] text-slate-400 mt-1 max-w-xs">
                This automation has not recorded any batch executions in the current registry.
              </p>
            </div>
          </div>
        )}

        {/* Empty state — search yields nothing */}
        {allBatches.length > 0 && filteredBatches.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center space-y-2 px-6">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wide">No results</p>
            <p className="text-[11px] text-slate-400 max-w-xs">
              No batch executions match <span className="font-mono text-slate-600">&quot;{searchQuery}&quot;</span>.
              <button onClick={() => handleSearch("")} className="ml-1 text-[#1d4ed8] hover:underline">Clear search</button>
            </p>
          </div>
        )}

        {/* Data table */}
        {paginatedBatches.length > 0 && (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-slate-50">
                <TableRow className="border-b border-slate-200">
                  <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 pl-5 w-[38%]">File Name</TableHead>
                  <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 w-[15%]">Status</TableHead>
                  <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 text-right w-[7%]">Total</TableHead>
                  <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 text-right w-[7%]">Success</TableHead>
                  <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 text-right w-[7%]">Failed</TableHead>
                  <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 text-right w-[9%]">Duration</TableHead>
                  <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 text-right pr-5 w-[17%]">Started At</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedBatches.map((batch) => (
                  <TableRow
                    key={batch.id}
                    className="border-b border-slate-100 last:border-0 hover:bg-slate-50/60 transition-colors"
                  >
                    <TableCell className="py-3.5 pl-5 font-mono text-[11px] text-slate-700 font-medium truncate max-w-[280px]" title={batch.file_name}>
                      {batch.file_name}
                    </TableCell>
                    <TableCell className="py-3.5">
                      <BatchStatus status={batch.status} />
                    </TableCell>
                    <TableCell className="py-3.5 text-right font-mono text-xs font-bold text-slate-800">
                      {batch.total_records}
                    </TableCell>
                    <TableCell className="py-3.5 text-right font-mono text-xs font-bold text-emerald-700">
                      {batch.success_records}
                    </TableCell>
                    <TableCell className="py-3.5 text-right font-mono text-xs font-bold text-rose-600">
                      {batch.failed_records > 0 ? batch.failed_records : <span className="text-slate-300">—</span>}
                    </TableCell>
                    <TableCell className="py-3.5 text-right font-mono text-xs text-slate-500">
                      {batch.duration}
                    </TableCell>
                    <TableCell className="py-3.5 text-right pr-5 text-xs text-slate-500 whitespace-nowrap">
                      {formatDate(batch.started_at)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Pagination */}
        {filteredBatches.length > PAGE_SIZE && (
          <div className="flex items-center justify-between px-5 py-3 border-t border-slate-100 bg-slate-50/40">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              {rangeStart}–{rangeEnd} of {filteredBatches.length}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                aria-label="Previous page"
                className="flex items-center justify-center h-7 w-7 rounded border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
              </button>
              <span className="text-[10px] font-bold text-slate-500 px-2">
                {currentPage} / {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                aria-label="Next page"
                className="flex items-center justify-center h-7 w-7 rounded border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
