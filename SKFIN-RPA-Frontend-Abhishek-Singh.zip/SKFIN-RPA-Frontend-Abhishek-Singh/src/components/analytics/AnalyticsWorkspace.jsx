"use client";

import React, { useState, useEffect } from "react";
import {
  RefreshCw,
  TrendingUp,
  AlertCircle,
  Clock,
  Database,
  CheckCircle2,
  XCircle,
  FileSpreadsheet,
  AlertTriangle,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as ChartTooltip,
} from "recharts";

import { mockAnalytics, mockDashboardSummary } from "@/data/mock";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function AnalyticsWorkspace() {
  const [selectedPeriod, setSelectedPeriod] = useState("daily");
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [hasError, setHasError] = useState(false);

  // Derive data directly from selectedPeriod — synchronous, no useEffect setState needed
  const analyticsData = mockAnalytics[selectedPeriod] ?? null;

  // Period change handler
  const handlePeriodChange = (period) => {
    setSelectedPeriod(period);
    setHasError(!mockAnalytics[period]);
  };

  // Manual refresh handler (button-triggered)
  const resolveAnalyticsData = () => {
    setIsRefreshing(true);
    setHasError(false);
    setTimeout(() => {
      setHasError(!mockAnalytics[selectedPeriod]);
      setIsRefreshing(false);
    }, 600);
  };

  // Page title — no setState here, safe
  useEffect(() => {
    const t = setTimeout(() => {
      document.title = "Analytics | SKFIN | RPA";
    }, 0);
    return () => clearTimeout(t);
  }, []);

  const getSuccessRateColor = (rate) => {
    if (rate >= 50) return "text-emerald-700 bg-emerald-50/50 border-emerald-200";
    if (rate >= 15) return "text-amber-700 bg-amber-50/50 border-amber-200";
    return "text-rose-700 bg-rose-50/50 border-rose-200";
  };

  const getCategoryBadgeColor = (category) => {
    switch (category) {
      case "FinnOne":
        return "text-[#1d4ed8] bg-blue-50 border-blue-200";
      case "SKI":
        return "text-emerald-700 bg-emerald-50 border-emerald-200";
      case "AZURE":
        return "text-purple-700 bg-purple-50 border-purple-200";
      default:
        return "text-slate-600 bg-slate-50 border-slate-200";
    }
  };

  const renderRateProgressBar = (rate) => {
    let filledBlocks = Math.round(rate / 10);
    if (rate > 0 && filledBlocks === 0) {
      filledBlocks = 1;
    }
    const emptyBlocks = 10 - filledBlocks;
    
    let barColor = "text-rose-500";
    if (rate >= 50) barColor = "text-emerald-500";
    else if (rate >= 15) barColor = "text-amber-500";

    return (
      <div className="flex items-center justify-center gap-2 font-mono text-[11px] select-none tracking-tight">
        <span className={barColor}>
          {"█".repeat(filledBlocks)}
          <span className="opacity-20 text-slate-400">{"░".repeat(emptyBlocks)}</span>
        </span>
        <span className={`px-1.5 py-0.5 rounded border text-[10px] font-bold ${getSuccessRateColor(rate)}`}>
          {rate.toFixed(1)}%
        </span>
      </div>
    );
  };

  if (hasError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] border border-slate-200 rounded-lg bg-white p-8 text-center space-y-4">
        <div className="flex items-center justify-center h-12 w-12 rounded-full bg-rose-50 text-rose-600">
          <AlertCircle className="h-6 w-6" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Analytics data unavailable</h2>
          <p className="text-xs text-slate-500 mt-1 max-w-sm">
            Unable to load the current analytics dataset from the platform registry.
          </p>
        </div>
        <Button onClick={resolveAnalyticsData} size="sm" className="bg-[#1d4ed8] hover:bg-[#1e40af] text-xs font-semibold px-4 py-2 text-white">
          <RefreshCw className="h-3.5 w-3.5 mr-2" />
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Analytics Page Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between border-b border-slate-200 pb-5">
        <div>
          <p className="text-[10px] font-bold tracking-widest text-[#1d4ed8] uppercase">
            System Operations Intelligence
          </p>
          <h1 className="text-xl font-extrabold text-slate-900 tracking-tight mt-1">Analytics</h1>
          <p className="text-xs text-slate-500 mt-1">
            Automation performance, distribution cycles, and error latency logs.
            {analyticsData?.date_range && (
              <span className="ml-2 text-[10px] font-bold text-slate-400 tracking-widest uppercase">
                {analyticsData.date_range.start === analyticsData.date_range.end
                  ? analyticsData.date_range.start
                  : `${analyticsData.date_range.start} → ${analyticsData.date_range.end}`}
              </span>
            )}
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 self-start md:self-center">
          <div className="flex border border-slate-200 rounded-lg bg-white p-0.5" role="group" aria-label="Time period scope selector">
            {["daily", "weekly", "monthly"].map((period) => (
              <button
                key={period}
                onClick={() => handlePeriodChange(period)}
                className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-md transition-colors ${
                  selectedPeriod === period
                    ? "bg-[#1d4ed8] text-white"
                    : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
                }`}
              >
                {period === "daily" ? "Today" : period === "weekly" ? "Weekly" : "Monthly"}
              </button>
            ))}
          </div>

          <Button
            onClick={resolveAnalyticsData}
            variant="outline"
            size="sm"
            disabled={isRefreshing}
            className="h-9 border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold px-3"
            aria-label="Refresh analytics data"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </div>

      {isRefreshing || !analyticsData ? (
        // Skeleton loading grid corresponding to analytics content
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="border-slate-200 bg-white">
                <CardHeader className="pb-2 space-y-1">
                  <Skeleton className="h-3 w-24 bg-slate-100" />
                  <Skeleton className="h-6 w-16 bg-slate-100" />
                </CardHeader>
              </Card>
            ))}
          </div>
          <Card className="border-slate-200 bg-white">
            <CardHeader>
              <Skeleton className="h-4 w-40 bg-slate-100" />
              <Skeleton className="h-3 w-64 mt-1 bg-slate-100" />
            </CardHeader>
            <CardContent className="h-[250px]">
              <Skeleton className="h-full w-full bg-slate-100" />
            </CardContent>
          </Card>
        </div>
      ) : (
        <>
          {/* Executive KPI Grid */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card className="border border-slate-200 bg-white shadow-xs">
              <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Records</span>
                <Database className="h-4 w-4 text-slate-400" />
              </CardHeader>
              <CardContent>
                <div className="text-xl font-black text-slate-900 tracking-tight">
                  {analyticsData.overview.total_records.toLocaleString()}
                </div>
                <p className="text-[9px] font-bold text-slate-400 tracking-wide uppercase mt-1">
                  {analyticsData.overview.avg_records_per_batch} records per batch average
                </p>
              </CardContent>
            </Card>

            <Card className="border border-slate-200 bg-white shadow-xs">
              <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Successful Batches</span>
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              </CardHeader>
              <CardContent>
                <div className="text-xl font-black text-emerald-700 tracking-tight">
                  {analyticsData.overview.successful_records.toLocaleString()}
                </div>
                <p className="text-[9px] font-bold text-slate-400 tracking-wide uppercase mt-1">
                  Processed without interruption
                </p>
              </CardContent>
            </Card>

            <Card className="border border-slate-200 bg-white shadow-xs">
              <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Failed Records</span>
                <XCircle className="h-4 w-4 text-rose-500" />
              </CardHeader>
              <CardContent>
                <div className="text-xl font-black text-rose-700 tracking-tight">
                  {analyticsData.overview.failed_records.toLocaleString()}
                </div>
                <p className="text-[9px] font-bold text-slate-400 tracking-wide uppercase mt-1">
                  Exceptions requires support intervention
                </p>
              </CardContent>
            </Card>

            <Card className="border border-slate-200 bg-white shadow-xs">
              <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Avg Process Duration</span>
                <Clock className="h-4 w-4 text-slate-400" />
              </CardHeader>
              <CardContent>
                <div className="text-xl font-black text-slate-900 tracking-tight">
                  {Math.floor(analyticsData.timing.avg_processing_time_seconds / 60)}m {Math.round(analyticsData.timing.avg_processing_time_seconds % 60)}s
                </div>
                <p className="text-[9px] font-bold text-slate-400 tracking-wide uppercase mt-1">
                  {analyticsData.timing.avg_time_per_record_seconds}s per record processing speed
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Trend & Distribution Visualization row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Record Processing volume Trend */}
            <Card className="lg:col-span-2 border border-slate-200 bg-white shadow-xs">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-[#1d4ed8]" />
                  <CardTitle className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                    Execution Trend Analysis
                  </CardTitle>
                </div>
                <CardDescription className="text-xs text-slate-500 mt-1">
                  Hourly and daily transaction records processing pattern.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[260px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={analyticsData.trend}
                      margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                    >
                      <defs>
                        <linearGradient id="colorSuccessful" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="colorFailed" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1}/>
                          <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                      <XAxis
                        dataKey="date"
                        stroke="#94a3b8"
                        fontSize={9}
                        fontWeight="bold"
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        stroke="#94a3b8"
                        fontSize={9}
                        fontWeight="bold"
                        tickLine={false}
                        axisLine={false}
                      />
                      <ChartTooltip
                        contentStyle={{
                          backgroundColor: "#0d1117",
                          border: "1px solid #1e2530",
                          borderRadius: "6px",
                          color: "#e2e8f0",
                          fontSize: "11px",
                          fontFamily: "monospace",
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="successful"
                        name="Success"
                        stroke="#10b981"
                        strokeWidth={2}
                        fillOpacity={1}
                        fill="url(#colorSuccessful)"
                      />
                      <Area
                        type="monotone"
                        dataKey="failed"
                        name="Exceptions"
                        stroke="#ef4444"
                        strokeWidth={2}
                        fillOpacity={1}
                        fill="url(#colorFailed)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Status Distribution horizontal distribution summary */}
            <Card className="border border-slate-200 bg-white shadow-xs flex flex-col">
              <CardHeader>
                <CardTitle className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                  Distribution Status
                </CardTitle>
                <CardDescription className="text-xs text-slate-500 mt-1">
                  Overall success and validation exception allocation.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col justify-center space-y-6">
                <div>
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-2">
                    <span className="flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-emerald-500" />
                      Success
                    </span>
                    <span>
                      {analyticsData.status_distribution.SUCCESSFUL} ({analyticsData.overview.success_rate.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 transition-all"
                      style={{ width: `${analyticsData.overview.success_rate}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-2">
                    <span className="flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-rose-500" />
                      Exceptions (Failed)
                    </span>
                    <span>
                      {analyticsData.status_distribution.FAILED} ({(100 - analyticsData.overview.success_rate).toFixed(1)}%)
                    </span>
                  </div>
                  <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-rose-500 transition-all"
                      style={{ width: `${100 - analyticsData.overview.success_rate}%` }}
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Scope validation: All processes</span>
                  <span>{analyticsData.overview.total_batches} batches</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Process performance table section */}
          <Card className="border border-slate-200 bg-white shadow-xs">
            <CardHeader className="pb-3 flex flex-col md:flex-row md:items-center md:justify-between space-y-2 md:space-y-0">
              <div>
                <CardTitle className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                  Process Performance Registry
                </CardTitle>
                <CardDescription className="text-xs text-slate-500 mt-1">
                  Individual process automation summaries and throughput rates.
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-slate-50">
                    <TableRow className="border-b border-slate-200">
                      <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 pl-6">Process</TableHead>
                      <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 text-center">Category</TableHead>
                      <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 text-center">Total Batches</TableHead>
                      <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 text-center">Total Records</TableHead>
                      <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 text-center">Success Rate</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockDashboardSummary.processes.map((proc) => (
                      <TableRow
                        key={proc.process_code}
                        className="hover:bg-slate-50/50 border-b border-slate-100 last:border-0 transition-colors"
                      >
                        <TableCell className="py-3.5 pl-6 font-semibold text-slate-900 text-xs">
                          {proc.process_name}
                        </TableCell>
                        <TableCell className="py-3.5 text-center">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold border ${getCategoryBadgeColor(proc.category)}`}>
                            {proc.category}
                          </span>
                        </TableCell>
                        <TableCell className="py-3.5 text-center text-slate-700 text-xs font-bold font-mono">
                          {proc.total_batches}
                        </TableCell>
                        <TableCell className="py-3.5 text-center text-slate-700 text-xs font-bold font-mono">
                          {proc.total_records}
                        </TableCell>
                        <TableCell className="py-3.5 text-center">
                          {renderRateProgressBar(proc.success_rate)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Details Row: Errors breakdown and execution timings */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Failure/Exception Categories */}
            <Card className="border border-slate-200 bg-white shadow-xs">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-rose-500" />
                  <CardTitle className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                    Operational Failure Categories
                  </CardTitle>
                </div>
                <CardDescription className="text-xs text-slate-500 mt-1">
                  Distribution of automation failure codes.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader className="bg-slate-50">
                      <TableRow className="border-b border-slate-200">
                        <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-2.5 pl-6">Exception Identifier</TableHead>
                        <TableHead className="text-[10px] font-bold text-slate-500 uppercase tracking-wider py-2.5 text-center">Occurrence Count</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {analyticsData.error_breakdown.map((err, idx) => (
                        <TableRow key={idx} className="border-b border-slate-100 last:border-0 hover:bg-slate-50/30">
                          <TableCell className="py-3 pl-6 font-mono text-[11px] text-slate-700 font-bold select-all">
                            {err.error_type}
                          </TableCell>
                          <TableCell className="py-3 text-center font-mono text-xs font-bold text-slate-950">
                            {err.count}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            {/* Execution timing analysis */}
            <Card className="border border-slate-200 bg-white shadow-xs flex flex-col justify-between">
              <div>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-[#1d4ed8]" />
                    <CardTitle className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                      Execution Timing Characteristics
                    </CardTitle>
                  </div>
                  <CardDescription className="text-xs text-slate-500 mt-1">
                    System processing latencies and record throughput cycles.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-2">
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Fastest</p>
                      <p className="text-sm font-black text-slate-900 mt-1 font-mono">{analyticsData.timing.min_processing_time_seconds}s</p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Average</p>
                      <p className="text-sm font-black text-slate-900 mt-1 font-mono">{Math.round(analyticsData.timing.avg_processing_time_seconds)}s</p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Longest</p>
                      <p className="text-sm font-black text-[#1d4ed8] mt-1 font-mono">{Math.round(analyticsData.timing.max_processing_time_seconds)}s</p>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-500">Record Processing Cadence:</span>
                      <span className="font-bold text-slate-900">{analyticsData.timing.avg_time_per_record_seconds} seconds/transaction</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-500">Global System Load:</span>
                      <span className="font-bold text-emerald-700">Nominal Efficiency</span>
                    </div>
                  </div>
                </CardContent>
              </div>
              <div className="px-6 pb-6 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                System Time Reference: Local client clock
              </div>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
