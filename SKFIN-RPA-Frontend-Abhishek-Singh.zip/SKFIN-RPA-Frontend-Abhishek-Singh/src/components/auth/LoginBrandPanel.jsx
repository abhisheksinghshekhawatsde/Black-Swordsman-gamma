import React from "react";
import Image from "next/image";

export default function LoginBrandPanel() {
  const systemStatus = [
    { name: "RPA ENGINE", status: "ONLINE" },
    { name: "PROCESS ORCHESTRATION", status: "ACTIVE" },
    { name: "API GATEWAY", status: "HEALTHY" },
    { name: "AUTHENTICATION", status: "SECURE" },
  ];

  const activeProcessFlows = [
    { idx: "01", code: "SKI_USER_CREATION", system: "SKI" },
    { idx: "02", code: "LOAN_SURAKSHA_POLICY", system: "FinnOne" },
    { idx: "03", code: "FINNONE_USER_CREATION", system: "FinnOne" },
    { idx: "04", code: "FINNONE_USER_DEACTIVATION", system: "FinnOne" },
    { idx: "05", code: "BRANCH_HIERARCHY", system: "FinnOne" },
    { idx: "06", code: "AZURE_USER_CREATION", system: "Azure" },
  ];

  return (
    <div className="relative hidden w-[55%] shrink-0 flex-col justify-between border-r border-[#141a24] bg-[#080c12] p-12 text-[#e2e8f0] lg:flex">
      {/* Grid Pattern Background */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.03) 1px, transparent 1px)",
          backgroundSize: "24px 24px",
        }}
        aria-hidden="true"
      />

      <div
        className="absolute inset-0 pointer-events-none opacity-10"
        style={{
          backgroundImage: "linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px)",
          backgroundSize: "100% 72px",
        }}
        aria-hidden="true"
      />

      {/* Top Header Logo + Brand Text */}
      <div className="relative z-10 flex items-center gap-4">
        <div className="relative h-14 w-12 shrink-0">
          <Image
            src="/branding/logo-main.png"
            alt="SK Finance Logo"
            fill
            sizes="48px"
            className="object-contain"
            priority
          />
        </div>
        <div>
          <h2 className="text-sm font-bold tracking-tight text-[#f1f5f9] uppercase">SK Finance</h2>
          <p className="text-[10px] font-semibold tracking-widest text-[#6b7280] uppercase">
            Enterprise Solutions
          </p>
        </div>
      </div>

      {/* Center Hero Description */}
      <div className="relative z-10 my-auto max-w-lg">
        <p className="mb-4 flex items-center gap-2 text-[10px] font-bold tracking-widest text-[#1d4ed8] uppercase">
          <span className="h-[1px] w-4 bg-[#1d4ed8]" />
          Automation Operations
        </p>
        <h1 className="text-4xl font-extrabold tracking-tight text-[#f1f5f9] leading-tight">
          Enterprise
          <br />
          <span className="font-light italic">Automation</span>
          <br />
          Platform
        </h1>
        <p className="mt-4 text-xs leading-relaxed text-[#6b7280] max-w-md">
          Centralized workflow orchestration, batch execution management, and operational analytics
          across core SK Finance processing systems.
        </p>
      </div>

      {/* Footer Details: System Status & Process Flows */}
      <div className="relative z-10 grid grid-cols-2 gap-8 border-t border-[#141a24] pt-8">
        {/* System Status Block */}
        <div>
          <div className="mb-3 flex items-center gap-2">
            <span className="text-[9px] font-bold tracking-wider text-[#374151] uppercase">
              System Status
            </span>
            <span className="h-[1px] flex-1 bg-[#141a24]" />
          </div>
          <ul className="flex flex-col gap-2">
            {systemStatus.map((item) => (
              <li
                key={item.name}
                className="flex items-center justify-between text-[10px] font-medium tracking-wide text-[#374151]"
              >
                <span>{item.name}</span>
                <span className="flex items-center gap-1.5 font-bold text-[#10b981]">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#10b981]" />
                  {item.status}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Process Flows Block */}
        <div>
          <div className="mb-3 flex items-center gap-2">
            <span className="text-[9px] font-bold tracking-wider text-[#374151] uppercase">
              Active Processes
            </span>
            <span className="h-[1px] flex-1 bg-[#141a24]" />
          </div>
          <ul className="flex flex-col gap-1.5">
            {activeProcessFlows.map((item) => (
              <li
                key={item.code}
                className="flex items-center gap-2 text-[10px] text-[#4b5563]"
              >
                <span className="font-mono text-[9px] text-[#1f2937]">{item.idx}</span>
                <span className="flex-1 truncate font-mono text-[9.5px] text-[#374151]">
                  {item.code}
                </span>
                <span className="text-[9px] font-bold text-[#1f2937] uppercase">{item.system}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Corporate Signatures */}
      <div className="relative z-10 mt-8 flex items-center justify-between border-t border-[#141a24]/50 pt-4 text-[9.5px] text-[#1f2937]">
        <span>© 2026 SK Finance. All rights reserved.</span>
        <span className="font-semibold tracking-wider text-[#1d4ed8] uppercase">
          Saath Aapke... Hamesha
        </span>
      </div>
    </div>
  );
}
