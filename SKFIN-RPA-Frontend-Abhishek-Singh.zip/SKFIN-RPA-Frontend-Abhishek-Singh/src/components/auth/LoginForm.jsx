"use client";

import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Eye, EyeOff, Loader2, Lock, Mail } from "lucide-react";

export default function LoginForm() {
  const { login } = useAuth();
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) return;

    setIsLoading(true);
    setErrorMsg("");

    try {
      const result = await login(email, password);
      if (result.success) {
        router.push("/dashboard");
      } else {
        setErrorMsg(result.error || "Unable to sign in with these credentials.");
        setIsLoading(false);
      }
    } catch {
      setErrorMsg("An unexpected operational error occurred.");
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-sm space-y-6">
      {/* Headings */}
      <div className="space-y-2">
        <div className="h-1 bg-gradient-to-r from-[#1d4ed8] to-transparent w-16 rounded-full" />
        <p className="text-[10px] font-bold tracking-widest text-[#1d4ed8] uppercase">Secure Access</p>
        <h2 className="text-2xl font-bold tracking-tight text-[#0d1117]">Sign in to Operations</h2>
        <p className="text-xs text-[#4b5563]">
          Access the internal SK Finance automation console.
        </p>
      </div>

      {/* Error Announcement */}
      {errorMsg && (
        <Alert variant="destructive" className="bg-red-50/50 border-red-200">
          <AlertDescription className="text-xs font-semibold text-red-800">
            {errorMsg}
          </AlertDescription>
        </Alert>
      )}

      {/* Form Fields */}
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        {/* Email Field */}
        <div className="space-y-1.5">
          <Label htmlFor="email" className="text-[10px] font-bold tracking-wider text-[#6b7280] uppercase">
            Work Email
          </Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              id="email"
              type="email"
              required
              autoComplete="email"
              placeholder="admin@skfin.in"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isLoading}
              className="pl-9 text-xs"
            />
          </div>
        </div>

        {/* Password Field */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="password" className="text-[10px] font-bold tracking-wider text-[#6b7280] uppercase">
              Password
            </Label>
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              required
              autoComplete="current-password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
              className="pl-9 pr-10 text-xs"
            />
            <button
              type="button"
              onClick={() => setShowPassword((prev) => !prev)}
              disabled={isLoading}
              aria-label={showPassword ? "Hide password" : "Show password"}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 transition-colors"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {/* Remember Me */}
        <div className="flex items-center space-x-2 pt-1">
          <Checkbox id="remember" disabled={isLoading} className="rounded" />
          <label
            htmlFor="remember"
            className="text-[11.5px] font-medium leading-none text-[#4b5563] cursor-pointer"
          >
            Remember this session
          </label>
        </div>

        {/* Submit */}
        <Button
          type="submit"
          disabled={isLoading || !email || !password}
          className="w-full bg-[#1d4ed8] hover:bg-[#1e40af] text-white text-xs font-bold uppercase tracking-wider h-10 transition-all focus-visible:ring-offset-2"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Authenticating
            </>
          ) : (
            "Sign In"
          )}
        </Button>
      </form>

      {/* Access Footer Info */}
      <div className="border-t border-slate-100 pt-4 text-[10px] text-slate-400 leading-normal">
        <p>Authentication is secured by enterprise access controls.</p>
        <p>Access is strictly limited to authorized SK Finance employees.</p>
      </div>
    </div>
  );
}
