"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { apiService } from "@/lib/api/service";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Layers,
  Database,
  CheckCircle2,
  Activity,
  ArrowRight,
  Search,
  RefreshCw,
} from "lucide-react";

export default function DashboardPage() {
  const [loading, setLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [summary, setSummary] = useState(null);
  const [filterCategory, setFilterCategory] = useState("ALL");
  const [searchQuery, setSearchQuery] = useState("");

  const loadSummary = async () => {
    setLoading(true);
    setHasError(false);
    try {
      const data = await apiService.getDashboardSummary();
      setSummary(data);
    } catch (_err) {
      setHasError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(() => {
      document.title = "Dashboard | SKFIN | RPA";
    }, 0);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadSummary();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="space-y-2">
          <Skeleton className="h-4 w-40" />
          <Skeleton className="h-8 w-60" />
          <Skeleton className="h-4 w-96" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-6 w-6 rounded" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-8 w-16" />
                <Skeleton className="h-3 w-32" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] border border-slate-200 rounded-lg bg-white p-8 text-center space-y-4">
        <div className="flex items-center justify-center h-12 w-12 rounded-full bg-rose-50 text-rose-600">
          <Activity className="h-6 w-6" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Unable to load dashboard data</h2>
          <p className="text-xs text-slate-500 mt-1 max-w-sm">
            The process registry could not be loaded. Retry to attempt reconnection.
          </p>
        </div>
        <Button onClick={loadSummary} size="sm" className="bg-[#1d4ed8] hover:bg-[#1e40af] text-xs font-semibold px-4 py-2 text-white">
          <RefreshCw className="h-3.5 w-3.5 mr-2" />
          Retry
        </Button>
      </div>
    );
  }

  const { global_summary, processes } = summary || {
    global_summary: { total_batches: 0, total_records: 0, overall_success_rate: 0, active_processes: 0 },
    processes: [],
  };

  const categories = ["ALL", "FinnOne", "SKI", "AZURE"];

  const filteredProcesses = processes.filter((proc) => {
    const matchCategory = filterCategory === "ALL" || proc.category === filterCategory;
    const matchSearch =
      proc.process_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      proc.process_code.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCategory && matchSearch;
  });

  const getSuccessRateColor = (rate) => {
    if (rate >= 50) return "text-emerald-700 bg-emerald-50/50 border-emerald-200";
    if (rate >= 15) return "text-amber-700 bg-amber-50/50 border-amber-200";
    return "text-rose-700 bg-rose-50/50 border-rose-200";
  };

  const getCategoryBadgeColor = (category) => {
    switch (category) {
      case "FinnOne":
        return "text-[#1d4ed8] bg-blue-50 border-blue-200";
      case "SKI":
        return "text-emerald-700 bg-emerald-50 border-emerald-200";
      case "AZURE":
        return "text-purple-700 bg-purple-50 border-purple-200";
      default:
        return "text-slate-600 bg-slate-50 border-slate-200";
    }
  };

  // Restrained visual representation for [██████░░░░] Success Rate progress bars
  const renderRateProgressBar = (rate) => {
    let filledBlocks = Math.round(rate / 10);
    // Ensure if percentage is greater than 0, we show at least 1 visual block filled.
    if (rate > 0 && filledBlocks === 0) {
      filledBlocks = 1;
    }
    const emptyBlocks = 10 - filledBlocks;
    
    // Choose dynamic color identifier
    let barColor = "text-rose-500";
    if (rate >= 50) barColor = "text-emerald-500";
    else if (rate >= 15) barColor = "text-amber-500";

    return (
      <div className="flex items-center gap-2 font-mono text-[11px] select-none tracking-tight">
        <span className={barColor}>
          {"█".repeat(filledBlocks)}
          <span className="opacity-20 text-slate-400">{"░".repeat(emptyBlocks)}</span>
        </span>
        <span className={`px-1.5 py-0.5 rounded border text-[10px] font-bold ${getSuccessRateColor(rate)}`}>
          {rate.toFixed(1)}%
        </span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Dashboard Page Header */}
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between border-b border-slate-200 pb-5">
        <div>
          <p className="text-[10px] font-bold tracking-widest text-[#1d4ed8] uppercase">
            Operations Overview
          </p>
          <h1 className="text-2xl font-bold tracking-tight text-[#0d1117]">Automation Dashboard</h1>
          <p className="text-xs text-[#4b5563]">
            Monitor active batch workflows, inspect success rates, and launch automation routines.
          </p>
        </div>
        <Button
          onClick={loadSummary}
          variant="outline"
          className="self-start md:self-auto text-xs font-semibold uppercase tracking-wider h-9"
        >
          <RefreshCw className="mr-2 h-3.5 w-3.5" />
          Refresh Console
        </Button>
      </div>

      {/* KPI Metric Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Total Batches
            </CardTitle>
            <Layers className="h-4 w-4 text-[#1d4ed8]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-mono font-bold text-[#0d1117]">
              {global_summary.total_batches.toLocaleString()}
            </div>
            <p className="text-[10px] text-slate-400 mt-1">All recorded execution sets</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Records Processed
            </CardTitle>
            <Database className="h-4 w-4 text-slate-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-mono font-bold text-[#0d1117]">
              {global_summary.total_records.toLocaleString()}
            </div>
            <p className="text-[10px] text-slate-400 mt-1">Across all automation runs</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Success Rate
            </CardTitle>
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-mono font-bold text-emerald-600">
              {global_summary.overall_success_rate}%
            </div>
            <p className="text-[10px] text-slate-400 mt-1">Successful vs total records</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Active Processes
            </CardTitle>
            <Activity className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-mono font-bold text-[#0d1117]">
              {global_summary.active_processes}
            </div>
            <p className="text-[10px] text-slate-400 mt-1">Registered RPA routines</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Process Registry Section */}
      <Card className="shadow-sm border border-slate-200">
        <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-100 bg-[#f8f9fb]/50 py-4">
          <div>
            <CardTitle className="text-sm font-bold text-[#0d1117]">Process Registry</CardTitle>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative w-full sm:w-60">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <Input
                type="text"
                placeholder="Search processes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 text-xs h-8 w-full"
              />
            </div>

            <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200" role="group">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilterCategory(cat)}
                  className={`text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-md transition-all ${
                    filterCategory === cat
                      ? "bg-white text-[#0d1117] shadow-sm"
                      : "text-slate-500 hover:text-[#0d1117]"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </CardHeader>

        {/* Desktop Representation: Precise Alignment Data Grid */}
        <div className="hidden md:block">
          <div className="w-full border-collapse text-left">
            {/* Custom Header Grid */}
            <div className="flex items-center bg-[#f8f9fb] border-b border-slate-200 text-[10px] font-bold text-slate-500 uppercase tracking-wider py-3 px-6 select-none text-center">
              <div className="w-[30%] text-left">Process</div>
              <div className="w-[12%] text-center">Category</div>
              <div className="w-[10%] text-center">Batches</div>
              <div className="w-[12%] text-center">Records</div>
              <div className="w-[20%] text-center">Success Rate</div>
              <div className="w-[12%] text-center">Last Execution</div>
              <div className="w-[4%] text-center min-w-[50px]">Action</div>
            </div>

            {/* Rows List */}
            <div className="divide-y divide-slate-100">
              {filteredProcesses.length === 0 ? (
                <div className="text-center py-12 text-xs text-slate-400 font-medium">
                  No matching registered processes discovered.
                </div>
              ) : (
                filteredProcesses.map((proc) => (
                  <div
                    key={proc.process_code}
                    className="flex items-center px-6 py-4 hover:bg-slate-50/50 transition-colors"
                  >
                    {/* Process Info */}
                    <div className="w-[30%] min-w-0 text-left">
                      <p className="text-xs font-bold text-[#0d1117] truncate">
                        {proc.process_name}
                      </p>
                    </div>

                    {/* Category */}
                    <div className="w-[12%] flex justify-center">
                      <Badge
                        className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border shadow-none ${getCategoryBadgeColor(
                          proc.category
                        )}`}
                        variant="outline"
                      >
                        {proc.category}
                      </Badge>
                    </div>

                    {/* Batches count (Centrally-aligned) */}
                    <div className="w-[10%] text-center font-mono text-xs font-semibold text-slate-700">
                      {proc.total_batches}
                    </div>

                    {/* Records count (Centrally-aligned) */}
                    <div className="w-[12%] text-center font-mono text-xs font-semibold text-slate-700">
                      {proc.total_records.toLocaleString()}
                    </div>

                    {/* Success Rate Bar Visual */}
                    <div className="w-[20%] flex justify-center">
                      <div className="w-[130px] flex items-center justify-center">
                        {renderRateProgressBar(proc.success_rate)}
                      </div>
                    </div>

                    {/* Last Execution Date */}
                    <div className="w-[12%] text-center text-[11px] text-slate-500 font-semibold font-mono">
                      {proc.last_batch_at ? (
                        new Date(proc.last_batch_at)
                          .toLocaleDateString("en-GB", {
                            day: "2-digit",
                            month: "short",
                            year: "numeric",
                          })
                          .replace(/ /g, " ")
                      ) : (
                        <span className="text-slate-300 font-normal select-none">—</span>
                      )}
                    </div>

                    {/* Navigation Actions */}
                    <div className="w-[4%] text-center min-w-[50px] flex justify-center">
                      <Link href={`/process/${proc.process_code}`} passHref>
                        <Button
                          variant="ghost"
                          className="text-[#1d4ed8] hover:text-[#1e40af] hover:bg-blue-50 text-xs font-bold px-2 h-8"
                        >
                          Open
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Mobile Representation: Compact Layout Cards */}
        <div className="block md:hidden">
          <div className="divide-y divide-slate-100">
            {filteredProcesses.length === 0 ? (
              <div className="text-center py-12 text-xs text-slate-400 font-medium">
                No matching registered processes discovered.
              </div>
            ) : (
              filteredProcesses.map((proc) => (
                <div key={proc.process_code} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-[#0d1117] truncate">
                        {proc.process_name}
                      </p>
                      <p className="font-mono text-[9px] text-slate-400 tracking-wide mt-0.5">
                        {proc.process_code}
                      </p>
                    </div>
                    <Badge
                      className={`text-[8.5px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border shrink-0 ${getCategoryBadgeColor(
                        proc.category
                      )}`}
                      variant="outline"
                    >
                      {proc.category}
                    </Badge>
                  </div>

                  {/* Operational Stats Grid */}
                  <div className="flex items-center justify-between text-[11px] text-slate-500 font-semibold bg-slate-50/50 p-2.5 rounded border border-slate-100">
                    <div className="space-y-0.5">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">
                        Batches / Records
                      </p>
                      <p className="font-mono text-slate-700">
                        {proc.total_batches} batches · {proc.total_records.toLocaleString()} records
                      </p>
                    </div>
                    <div className="text-right space-y-0.5">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">
                        Last Run
                      </p>
                      <p className="font-mono text-slate-700">
                        {proc.last_batch_at ? (
                          new Date(proc.last_batch_at)
                            .toLocaleDateString("en-GB", {
                              day: "2-digit",
                              month: "short",
                              year: "numeric",
                            })
                        ) : (
                          "—"
                        )}
                      </p>
                    </div>
                  </div>

                  {/* Progress and Link */}
                  <div className="flex items-center justify-between gap-4 pt-1">
                    <div>{renderRateProgressBar(proc.success_rate)}</div>
                    <Link href={`/process/${proc.process_code}`} passHref>
                      <Button
                        variant="outline"
                        className="text-xs font-bold h-8 text-[#1d4ed8] border-slate-200"
                      >
                        View Details
                        <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
                      </Button>
                    </Link>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
