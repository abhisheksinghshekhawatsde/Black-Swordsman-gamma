"use client";

import React, { useEffect } from "react";
import ProcessWorkspace from "@/components/processes/ProcessWorkspace";
import { mockProcesses } from "@/data/mock";

function normalizeCode(raw) {
  return raw?.toUpperCase().replace(/-/g, "_") ?? "";
}

export default function ProcessPage({ params }) {
  const resolvedParams = React.use(params);
  const rawCode = resolvedParams?.processCode ?? "";
  const processCode = normalizeCode(rawCode);
  const processDef = mockProcesses.find((p) => p.code === processCode);

  // Document title — only uses setTimeout per established pattern, no setState
  useEffect(() => {
    const t = setTimeout(() => {
      document.title = processDef
        ? `${processDef.name} | SKFIN | RPA`
        : "Process Not Found | SKFIN | RPA";
    }, 0);
    return () => clearTimeout(t);
  }, [processDef]);

  return <ProcessWorkspace rawCode={rawCode} />;
}
