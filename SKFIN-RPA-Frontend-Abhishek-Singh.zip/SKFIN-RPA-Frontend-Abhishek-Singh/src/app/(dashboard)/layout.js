"use client";

import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import OperationsShell from "@/components/shell/OperationsShell";

export default function DashboardLayout({ children }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.replace("/login");
    }
  }, [user, loading, router]);

  if (loading || !user) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-[#0a0e16] text-[#e2e8f0] font-semibold">
        Verifying Session...
      </div>
    );
  }

  return <OperationsShell>{children}</OperationsShell>;
}
