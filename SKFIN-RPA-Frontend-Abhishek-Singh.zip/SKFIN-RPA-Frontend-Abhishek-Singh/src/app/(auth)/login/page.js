"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import Image from "next/image";
import LoginBrandPanel from "@/components/auth/LoginBrandPanel";
import LoginForm from "@/components/auth/LoginForm";

export default function LoginPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    const t = setTimeout(() => {
      document.title = "Login | SKFIN | RPA";
    }, 0);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!loading && user) {
      router.replace("/dashboard");
    }
  }, [user, loading, router]);

  if (loading || user) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-[#0a0e16] text-[#e2e8f0] font-semibold">
        Verifying Credentials...
      </div>
    );
  }
  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0a0e16]">
      {/* Left panel */}
      <LoginBrandPanel />

      {/* Right panel */}
      <div className="relative flex flex-1 flex-col items-center justify-center p-8 bg-[#0a0e16] lg:bg-white transition-colors duration-150">
        {/* Subtle grid pattern for light/dark theme panels */}
        <div
          className="absolute inset-0 pointer-events-none opacity-[0.015] lg:opacity-[0.03]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(0,0,0,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.1) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
          aria-hidden="true"
        />

        {/* Mobile Header Logo */}
        <div className="absolute top-8 left-8 flex items-center gap-3 lg:hidden">
          <div className="relative h-10 w-8 shrink-0">
            <Image
              src="/branding/logo-main.png"
              alt="SK Finance Logo"
              fill
              sizes="32px"
              className="object-contain"
              priority
            />
          </div>
          <div>
            <h1 className="text-xs font-bold text-white tracking-wide uppercase">SK Finance</h1>
            <p className="text-[8.5px] font-bold text-slate-500 uppercase tracking-widest">
              RPA Operations
            </p>
          </div>
        </div>

        {/* Login Form Wrapper */}
        <div className="relative z-10 w-full max-w-sm rounded-xl p-8 bg-[#0d1117] border border-[#1e2738]/50 shadow-2xl lg:shadow-none lg:border-none lg:bg-transparent transition-all">
          <LoginForm />
        </div>

        {/* Mobile Footer tagline */}
        <div className="absolute bottom-8 text-[9px] text-slate-500 font-semibold tracking-wider uppercase lg:hidden">
          Saath Aapke... Hamesha
        </div>
      </div>
    </div>
  );
}
