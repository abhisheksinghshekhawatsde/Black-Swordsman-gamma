export const mockProcesses = [
  {
    code: "SKI_USER_CREATION",
    name: "SKI User Creation",
    category: "SKI",
    description: "Automated user creation in SKI system.",
    ui_config: null,
    version: "1.0",
    is_active: true,
  },
  {
    code: "LOAN_SURAKSHA_POLICY",
    name: "Loan Suraksha Policy",
    category: "FinnOne",
    description: "Automated upload of Loan Suraksha Policy PDFs to FinnOne LMS. Watches a local directory for PDFs, extracts loan/policy details via EasyOCR, then uploads through the PDD Maker desk.",
    ui_config: {
      actions: [
        {
          type: "UPLOAD_LOAN_SURAKSHA_POLICY",
          description: "Upload Loan Suraksha Policy PDF to FinnOne LMS via PDD Maker",
        }
      ],
      page_config: {
        title: "Loan Suraksha Policy",
        buttons: { upload_excel: false, download_data: true, download_template: false }
      },
      input_schema: {
        pdf_filename: { label: "PDF Filename", db_map: "pdf_filename", source: "system", required: true, data_type: "string" },
        customer_name: { label: "Customer Name", db_map: "customer_name", source: "ocr", required: false, data_type: "string" },
        pdf_file_path: { label: "PDF File Path", db_map: "pdf_file_path", source: "system", required: true, data_type: "string" },
        policy_number: { label: "Policy Number", db_map: "policy_number", source: "ocr", required: true, data_type: "string" },
        loan_account_no: { label: "Loan Account Number", db_map: "loan_account_no", source: "ocr", required: true, data_type: "string" },
        policy_end_date: { label: "Policy End Date", db_map: "policy_end_date", source: "ocr", required: false, data_type: "date" },
        policy_start_date: { label: "Policy Start Date", db_map: "policy_start_date", source: "ocr", required: false, data_type: "date" }
      },
      finnone_config: {
        module: "LMS",
        navigation: ["Maker Desk", "Miscellaneous", "PDD Maker"],
        document_name: "Loan Suraksha Policy"
      },
      validation_rules: [
        { rule: "required", field: "loan_account_no" },
        { rule: "required", field: "policy_number" },
        { rule: "required|file_exists", field: "pdf_file_path" }
      ]
    },
    version: "1.0",
    is_active: true,
  },
  {
    code: "FINNONE_USER_DEACTIVATION",
    name: "FinnOne User Deactivation",
    category: "FinnOne",
    description: "Automated user deactivation in FinnOne LOS system.",
    ui_config: null,
    version: "1.0",
    is_active: true,
  },
  {
    code: "FINNONE_USER_CREATION",
    name: "FinnOne User Creation",
    category: "FinnOne",
    description: "Automated user creation in FinnOne LOS system.",
    ui_config: {
      actions: [
        {
          type: "CREATE_USER",
          description: "Create a new user in FinnOne LOS system"
        }
      ],
      excel_schema: {
        city: { label: "City", db_map: "city", required: true, data_type: "string" },
        roles: { label: "Roles", db_map: "roles", required: true, data_type: "string" },
        state: { label: "State", db_map: "state", required: true, data_type: "string" },
        mobile: { label: "Mobile", db_map: "mobile", required: false, data_type: "string" },
        region: { label: "Region", db_map: "region", required: true, data_type: "string" },
        country: { label: "Country", db_map: "country", required: true, data_type: "string" },
        district: { label: "District", db_map: "district", required: true, data_type: "string" },
        email_id: { label: "Email ID", db_map: "email_id", required: true, data_type: "string", validation: { pattern: "^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$" } },
        pin_code: { label: "PIN Code", db_map: "pin_code", required: true, data_type: "string" },
        last_name: { label: "Last Name", db_map: "last_name", required: true, data_type: "string" },
        user_name: { label: "User Name", db_map: "user_name", required: true, data_type: "string" },
        bi_product: { label: "BI Product", db_map: "bi_product", required: false, data_type: "string" },
        first_name: { label: "First Name", db_map: "first_name", required: true, data_type: "string" },
        salutation: { label: "Salutation", db_map: "salutation", required: true, data_type: "string", validation: { enum: ["Mr.", "Mrs.", "Ms.", "Dr."] } },
        user_class: { label: "User Class", db_map: "user_class", required: true, data_type: "string" },
        access_type: { label: "Access Type", db_map: "access_type", required: true, data_type: "string" },
        branch_name: { label: "Branch Name", db_map: "branch_name", required: true, data_type: "string" },
        middle_name: { label: "Middle Name", db_map: "middle_name", required: false, data_type: "string" },
        module_name: { label: "Module Name", db_map: "module_name", required: true, data_type: "string" },
        employee_hub: { label: "Employee Hub", db_map: "employee_hub", required: false, data_type: "string" },
        product_name: { label: "Product Name", db_map: "product_name", required: false, data_type: "string" },
        user_category: { label: "User Category", db_map: "user_category", required: true, data_type: "string" },
        address_line_1: { label: "Address Line 1", db_map: "address_line_1", required: true, data_type: "string" },
        address_line_2: { label: "Address Line 2", db_map: "address_line_2", required: false, data_type: "string" },
        date_of_joining: { label: "Date of Joining", db_map: "date_of_joining", required: true, data_type: "date" },
        flat_plot_number: { label: "Flat/Plot Number", db_map: "flat_plot_number", required: false, data_type: "string" },
        is_login_enabled: { label: "Is Login Enabled", db_map: "is_login_enabled", required: true, data_type: "string" },
        user_department_id: { label: "User Department ID", db_map: "user_department_id", required: true, data_type: "string" },
        communication_teams: { label: "Communication Teams", db_map: "communication_teams", required: false, data_type: "string" }
      },
      validation_rules: [
        { rule: "required", field: "user_name" },
        { rule: "required|format", field: "email_id" },
        { rule: "required", field: "first_name" },
        { rule: "required", field: "last_name" },
        { rule: "required", field: "date_of_joining" },
        { rule: "unique", field: "user_name" }
      ]
    },
    version: "1.0",
    is_active: true,
  },
  {
    code: "BRANCH_HIERARCHY",
    name: "FinnOne Branch Hierarchy",
    category: "FinnOne",
    description: "Automated branch hierarchy management in FinnOne — branch creation, CRE movement, RM/supervisor updates with maker-checker approval",
    ui_config: {
      actions: [
        { type: "CREATE_BRANCH", description: "Create a new branch in FinnOne hierarchy" },
        { type: "ADD_CRE", description: "Add a CRE to a branch hierarchy" },
        { type: "MOVE_CRE", description: "Move a CRE from one branch to another" },
        { type: "REMOVE_CRE", description: "Remove a CRE from branch hierarchy (exit)" },
        { type: "UPDATE_RM", description: "Update RM assignment for a branch" },
        { type: "UPDATE_SUPERVISOR", description: "Update supervisor assignment for an RM" }
      ],
      excel_schema: {
        cre_code: { label: "CRE Code", db_map: "cre_code", required: true, data_type: "string" },
        cre_name: { label: "CRE Name", db_map: "cre_name", required: true, data_type: "string" },
        new_rm_code: { label: "New RM Code", db_map: "new_rm_code", required: true, data_type: "string" },
        new_rm_name: { label: "New RM Name", db_map: "new_rm_name", required: true, data_type: "string" },
        old_rm_code: { label: "Old RM Code", db_map: "old_rm_code", required: false, data_type: "string" },
        old_rm_name: { label: "Old RM Name", db_map: "old_rm_name", required: false, data_type: "string" },
        rm_mismatch: { label: "RM Mismatch", db_map: "rm_mismatch", required: false, data_type: "boolean" },
        current_designation: { label: "Current Designation", db_map: "cre_designation", required: true, data_type: "string" },
        new_supervisor_code: { label: "New Supervisor Code", db_map: "new_supervisor_code", required: true, data_type: "string" },
        old_supervisor_code: { label: "Old Supervisor Code", db_map: "old_supervisor_code", required: false, data_type: "string" },
        supervisor_mismatch: { label: "Supervisor Mismatch", db_map: "supervisor_mismatch", required: false, data_type: "boolean" },
        old_cre_branch_hierarchy: { label: "Old CRE Branch Hierarchy", db_map: "old_branch_hierarchy", required: false, data_type: "string" },
        current_cre_branch_hierarchy: { label: "Current CRE Branch Hierarchy", db_map: "current_branch_hierarchy", required: true, data_type: "string" },
        cre_branch_hierarchy_mismatch: { label: "Branch Hierarchy Mismatch", db_map: "cre_branch_hierarchy_mismatch", required: false, data_type: "boolean" },
        cre_exist_in_finnone_hierarchy: { label: "CRE Exist in FinnOne Hierarchy", db_map: "cre_exist_in_finnone_hierarchy", required: false, data_type: "boolean" }
      },
      validation_rules: [
        { rule: "required", field: "cre_code" },
        { rule: "required", field: "cre_name" },
        { rule: "required", field: "current_cre_branch_hierarchy" },
        { rule: "required", field: "current_designation" },
        { rule: "required", field: "new_rm_code" },
        { rule: "required", field: "new_rm_name" },
        { rule: "required", field: "new_supervisor_code" }
      ]
    },
    version: "1.0",
    is_active: true,
  },
  {
    code: "AZURE_USER_CREATION",
    name: "Azure User Creation",
    category: "AZURE",
    description: "Automated user creation in Microsoft Entra ID (Azure Portal)",
    ui_config: null,
    version: "1.0",
    is_active: true,
  }
];

export const mockDashboardSummary = {
  global_summary: {
    total_batches: 568,
    total_records: 1204,
    overall_success_rate: 16.3,
    active_processes: 6
  },
  processes: [
    { process_code: "LOAN_SURAKSHA_POLICY", process_name: "Loan Suraksha Policy", category: "FinnOne", total_batches: 325, total_records: 323, success_rate: 3.4, last_batch_at: "2026-08-20T12:12:37.300Z" },
    { process_code: "SKI_USER_CREATION", process_name: "SKI User Creation", category: "SKI", total_batches: 116, total_records: 216, success_rate: 19.0, last_batch_at: "2026-08-06T17:48:33.564Z" },
    { process_code: "FINNONE_USER_CREATION", process_name: "FinnOne User Creation", category: "FinnOne", total_batches: 59, total_records: 78, success_rate: 55.1, last_batch_at: "2026-08-06T17:55:53.342Z" },
    { process_code: "FINNONE_USER_DEACTIVATION", process_name: "FinnOne User Deactivation", category: "FinnOne", total_batches: 41, total_records: 210, success_rate: 20.5, last_batch_at: "2026-08-03T16:03:40.540Z" },
    { process_code: "BRANCH_HIERARCHY", process_name: "FinnOne Branch Hierarchy", category: "FinnOne", total_batches: 27, total_records: 377, success_rate: 15.4, last_batch_at: "2026-07-24T16:20:58.026Z" },
    { process_code: "AZURE_USER_CREATION", process_name: "Azure User Creation", category: "AZURE", total_batches: 0, total_records: 0, success_rate: 0.0, last_batch_at: null }
  ]
};

export const mockBatches = {
  BRANCH_HIERARCHY: [
    { id: 1, file_name: "branch_hierarchy_template 13-06-2026.xlsx", status: "PROCESSING", total_records: 23, success_records: 0, failed_records: 0, duration: "N/A", started_at: "2026-07-24T16:20:00Z" },
    { id: 2, file_name: "branch_hierarchy_template_19-03-2026 (1).xlsx", status: "COMPLETED WITH ERRORS", total_records: 29, success_records: 28, failed_records: 1, duration: "13m 9s", started_at: "2026-07-21T16:14:00Z" },
    { id: 3, file_name: "branch_hierarchy_template_19-03-2026.xlsx", status: "FAILED", total_records: 29, success_records: 0, failed_records: 0, duration: "31s", started_at: "2026-07-17T09:55:00Z" },
    { id: 4, file_name: "branch_hierarchy_template 19-03-2026.xlsx", status: "PROCESSING", total_records: 29, success_records: 0, failed_records: 0, duration: "N/A", started_at: "2026-07-15T16:26:00Z" },
    { id: 5, file_name: "branch_hierarchy_template_17-06-2026_3_.xlsx", status: "COMPLETED WITH ERRORS", total_records: 22, success_records: 3, failed_records: 19, duration: "11m 55s", started_at: "2026-07-13T16:54:00Z" },
    { id: 6, file_name: "branch_hierarchy_template 17-06-2026(3).xlsx", status: "FAILED", total_records: 22, success_records: 0, failed_records: 22, duration: "30m 24s", started_at: "2026-07-04T13:00:00Z" }
  ],
  LOAN_SURAKSHA_POLICY: [
    { id: 1, file_name: "loan_suraksha_policy_batch_20-08-2026.xlsx", status: "COMPLETED", total_records: 15, success_records: 15, failed_records: 0, duration: "2m 14s", started_at: "2026-08-20T12:12:00Z" },
    { id: 2, file_name: "loan_suraksha_policy_batch_19-08-2026.xlsx", status: "COMPLETED WITH ERRORS", total_records: 12, success_records: 11, failed_records: 1, duration: "1m 45s", started_at: "2026-08-19T14:32:00Z" }
  ]
};

export const mockAnalytics = {
  daily: {
    process_code: null,
    process_name: "All Processes",
    period: "daily",
    date_range: { start: "2026-08-20", end: "2026-08-20" },
    overview: {
      total_batches: 14,
      total_records: 52,
      successful_records: 9,
      failed_records: 43,
      skipped_records: 0,
      success_rate: 17.3,
      avg_records_per_batch: 4
    },
    timing: {
      avg_processing_time_seconds: 134.0,
      min_processing_time_seconds: 31,
      max_processing_time_seconds: 420.0,
      avg_time_per_record_seconds: 52.3
    },
    status_distribution: { SUCCESSFUL: 9, FAILED: 43 },
    trend: [
      { date: "06:00", batches: 2, records: 8,  successful: 2, failed: 6,  success_rate: 25.0 },
      { date: "08:00", batches: 3, records: 12, successful: 1, failed: 11, success_rate: 8.3  },
      { date: "10:00", batches: 4, records: 14, successful: 4, failed: 10, success_rate: 28.6 },
      { date: "12:00", batches: 2, records: 7,  successful: 0, failed: 7,  success_rate: 0.0  },
      { date: "14:00", batches: 3, records: 11, successful: 2, failed: 9,  success_rate: 18.2 }
    ],
    error_breakdown: [
      { error_type: "FINNONE_CONNECTION_TIMEOUT", count: 21 },
      { error_type: "LOAN_LOOKUP_ERROR",          count: 13 },
      { error_type: "OCR_EXTRACTION_FAILURE",     count: 6  },
      { error_type: "CRE_BELONGS_TO_ANOTHER_BRANCH", count: 3 }
    ]
  },
  weekly: {
    process_code: null,
    process_name: "All Processes",
    period: "weekly",
    date_range: { start: "2026-08-14", end: "2026-08-20" },
    overview: {
      total_batches: 96,
      total_records: 371,
      successful_records: 68,
      failed_records: 303,
      skipped_records: 0,
      success_rate: 18.3,
      avg_records_per_batch: 4
    },
    timing: {
      avg_processing_time_seconds: 198.4,
      min_processing_time_seconds: 31,
      max_processing_time_seconds: 714.9,
      avg_time_per_record_seconds: 61.2
    },
    status_distribution: { SUCCESSFUL: 68, FAILED: 303 },
    trend: [
      { date: "Mon 14", batches: 8,  records: 31,  successful: 7,  failed: 24,  success_rate: 22.6 },
      { date: "Tue 15", batches: 21, records: 86,  successful: 15, failed: 71,  success_rate: 17.4 },
      { date: "Wed 16", batches: 14, records: 55,  successful: 12, failed: 43,  success_rate: 21.8 },
      { date: "Thu 17", batches: 19, records: 74,  successful: 10, failed: 64,  success_rate: 13.5 },
      { date: "Fri 18", batches: 20, records: 77,  successful: 19, failed: 58,  success_rate: 24.7 },
      { date: "Sat 19", batches: 9,  records: 34,  successful: 4,  failed: 30,  success_rate: 11.8 },
      { date: "Sun 20", batches: 5,  records: 14,  successful: 1,  failed: 13,  success_rate: 7.1  }
    ],
    error_breakdown: [
      { error_type: "FINNONE_CONNECTION_TIMEOUT",    count: 148 },
      { error_type: "LOAN_LOOKUP_ERROR",             count: 91  },
      { error_type: "OCR_EXTRACTION_FAILURE",        count: 42  },
      { error_type: "CRE_BELONGS_TO_ANOTHER_BRANCH", count: 22  }
    ]
  },
  monthly: {
    process_code: null,
    process_name: "All Processes",
    period: "monthly",
    date_range: { start: "2026-08-01", end: "2026-08-20" },
    overview: {
      total_batches: 323,
      total_records: 1204,
      successful_records: 196,
      failed_records: 1008,
      skipped_records: 0,
      success_rate: 16.3,
      avg_records_per_batch: 4
    },
    timing: {
      avg_processing_time_seconds: 245.8,
      min_processing_time_seconds: 31,
      max_processing_time_seconds: 714.9,
      avg_time_per_record_seconds: 68.4
    },
    status_distribution: { SUCCESSFUL: 196, FAILED: 1008 },
    trend: [
      { date: "Aug 06", batches: 12,  records: 24,  successful: 7,   failed: 17,  success_rate: 29.2 },
      { date: "Aug 10", batches: 310, records: 310, successful: 0,   failed: 310, success_rate: 0.0  },
      { date: "Aug 15", batches: 1,   records: 216, successful: 110, failed: 106, success_rate: 50.9 },
      { date: "Aug 18", batches: 27,  records: 377, successful: 58,  failed: 319, success_rate: 15.4 },
      { date: "Aug 20", batches: 1,   records: 1,   successful: 0,   failed: 1,   success_rate: 0.0  }
    ],
    error_breakdown: [
      { error_type: "FINNONE_CONNECTION_TIMEOUT",    count: 489 },
      { error_type: "LOAN_LOOKUP_ERROR",             count: 311 },
      { error_type: "OCR_EXTRACTION_FAILURE",        count: 128 },
      { error_type: "CRE_BELONGS_TO_ANOTHER_BRANCH", count: 80  }
    ]
  }
};
